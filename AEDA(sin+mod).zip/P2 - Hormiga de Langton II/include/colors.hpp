#pragma once

#define BRED "\033[1;31m"
#define BGREEN "\033[1;32m"
#define BYELL "\033[1;33m"
#define BMAGT "\033[1;35m"
#define BCYAN "\033[1;36m"

#define RED_BG "\033[41m"
#define CYAN_BG "\033[42m" 

#define RESET "\033[0m"

//int x = rand() % _x;
//int y = rand() % _y;
//_malla[y][x] = 1;
//void setRandom() { srand(time(0)); _malla[rand()%_height][rand()%_width] = 1; }
/*for(int i = 0; i<10000000; i++) {
    std::cout << M;
    M.setRandom();
}*/